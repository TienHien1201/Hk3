package Test;

import Controller.Sukien;
import View.view;
import model.Admin;

public class test {
public static void main(String[] args) {
	Admin a = new  Admin();
Sukien s = new Sukien();
view v = new view(a);
}
}
