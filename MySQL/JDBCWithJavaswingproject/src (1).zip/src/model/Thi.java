package model;

public class Thi {
private String maMT;
private String maCN;
public Thi(String maMT, String maCN) {
	
	this.maMT = maMT;
	this.maCN = maCN;
}
public Thi() {
	
}
public String getMaMT() {
	return maMT;
}
public void setMaMT(String maMT) {
	this.maMT = maMT;
}
public String getMaCN() {
	return maCN;
}
public void setMaCN(String maCN) {
	this.maCN = maCN;
}


}
